export const environment = {
  production: true,
  apiUrl: 'http://localhost:8090',
  googleClientId: '328681200787-bfr523r6ettgr11ir0r87kjag0tmlkcu.apps.googleusercontent.com'
};